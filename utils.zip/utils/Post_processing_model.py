import cv2
import numpy as np

def save_segmented_objects(image, instances, class_names, output_dir):
    segmented_objects = []
    for i in range(len(instances)):
        bbox = instances.pred_boxes[i].tensor.cpu().numpy().astype(int)[0]
        x1, y1, x2, y2 = bbox
        instance_image = image[y1:y2, x1:x2]
        class_id = instances.pred_classes[i].item()
        class_name = class_names[class_id]
        segmented_objects.append((instance_image, class_name))
        cv2.imwrite(f"{output_dir}/{class_name}_{i}.png", instance_image)
    return segmented_objects
