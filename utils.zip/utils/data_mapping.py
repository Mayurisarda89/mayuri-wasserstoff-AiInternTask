import json

def map_data(instances, class_names, descriptions, output_file):
    data_mapping = {}
    for i, instance in enumerate(instances):
        bbox = instance['bbox']
        data_mapping[i + 1] = {
            "object": instance['class_name'],
            "text": instance['text'],
            "description": descriptions[i],
            "bounding_box": [int(coord) for coord in bbox.tolist()]
        }
    
    with open(output_file, 'w') as json_file:
        json.dump(data_mapping, json_file, indent=4)
    return data_mapping
