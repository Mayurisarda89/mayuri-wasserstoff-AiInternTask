import cv2
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import pandas as pd

def visualize_output(image, instances, class_names, descriptions, data_mapping):
    fig, ax = plt.subplots(1, 2, figsize=(15, 10))

    ax[0].imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    ax[0].set_title('Original Image with Annotations')
    ax[0].axis('off')

    for i in range(len(instances)):
        bbox = instances[i]['bbox']
        x1, y1, x2, y2 = bbox
        rect = Rectangle((x1, y1), x2 - x1, y2 - y1, linewidth=2, edgecolor='red', facecolor='none')
        ax[0].add_patch(rect)

        class_name = instances[i]['class_name']
        description = descriptions[i]
        ax[0].text(x1, y1, f"{class_name}: {description}", color='white', fontsize=10, bbox=dict(facecolor='red', alpha=0.5))

    table_data = []
    for obj_id, attributes in data_mapping.items():
        table_data.append({
            "ID": obj_id,
            "Object": attributes["object"],
            "Text": attributes["text"],
            "Description": attributes["description"],
            "Bounding Box": attributes["bounding_box"]
        })

    df = pd.DataFrame(table_data)
    ax[1].axis('off')
    ax[1].table(cellText=df.values, colLabels=df.columns, cellLoc='center', loc='center', bbox=[0, 0, 1, 1])

    plt.tight_layout()
    plt.show()
