import cv2

def load_image(image_path):
    image = cv2.imread(image_path)
    if image is None:
        raise ValueError(f"Error: Unable to load image at {image_path}. The file may be corrupted or path is incorrect.")
    return image
