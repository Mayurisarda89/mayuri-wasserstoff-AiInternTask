import sqlite3

def save_descriptions_to_db(descriptions, db_path='segmented_objects.db'):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("DROP TABLE IF EXISTS extracted_text")
    cursor.execute('''CREATE TABLE extracted_text (
                        s_no INTEGER PRIMARY KEY AUTOINCREMENT,
                        master_id INTEGER,
                        unique_id INTEGER,
                        object TEXT,
                        text TEXT,
                        description TEXT
                     )''')

    master_id = 1
    for i, desc in enumerate(descriptions):
        cursor.execute("INSERT INTO extracted_text (master_id, unique_id, object, text, description) VALUES (?, ?, ?, ?, ?)",
                       (master_id, i + 1, desc['object'], desc['text'], desc['description']))

    conn.commit()
    conn.close()
