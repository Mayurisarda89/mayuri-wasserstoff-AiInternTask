import easyocr

def load_text_extraction_model():
    reader = easyocr.Reader(['en'])
    return reader

def extract_text(reader, image):
    ocr_results = reader.readtext(image)
    detected_texts = [text for (_, text, _) in ocr_results]
    detected_text = ' '.join(detected_texts) if detected_texts else "No text detected"
    return detected_text
